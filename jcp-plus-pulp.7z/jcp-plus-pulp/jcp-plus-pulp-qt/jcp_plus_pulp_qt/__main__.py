from jcp_plus_pulp_qt.main import main

main()
