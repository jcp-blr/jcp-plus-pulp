from .query2 import query

__all__ = ["query"]
