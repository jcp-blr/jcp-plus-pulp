import os
import sys

# This will cause imports to use the packages in the
# source folder instead of those installed on the system.
sys.path.insert(0, os.path.abspath(".."))
