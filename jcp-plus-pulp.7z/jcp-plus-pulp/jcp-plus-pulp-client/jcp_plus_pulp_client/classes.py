"""
Default classes

Taken from default classes in jcp-plus-pulp-webui
"""
import logging
import random
from typing import (
    Any,
    Dict,
    List,
    Tuple,
)

import jcp_plus_pulp_client

logger = logging.getLogger(__name__)

CategoryId = List[str]
CategorySpec = Dict[str, Any]

default_classes: List[Tuple[CategoryId, CategorySpec]] = [
    (["Work"], {"type": "regex", "regex": "Google Docs|libreoffice|ReText"}),
    (
        ["Work", "Programming"],
        {
            "type": "regex",
            "regex": "GitHub|Stack Overflow|BitBucket|Gitlab|vim|Spyder|kate|Ghidra|Scite",
        },
    ),
    (
        ["Work", "Programming", "JCP+ PULP"],
        {"type": "regex", "regex": "JCP+ PULP|jcp-plus-pulp-", "ignore_case": True},
    ),
    (["Work", "Image"], {"type": "regex", "regex": "Gimp|Inkscape"}),
    (["Work", "Video"], {"type": "regex", "regex": "Kdenlive"}),
    (["Work", "Audio"], {"type": "regex", "regex": "Audacity"}),
    (["Work", "3D"], {"type": "regex", "regex": "Blender"}),
    (["Media", "Games"], {"type": "regex", "regex": "Minecraft|RimWorld"}),
    (["Media", "Video"], {"type": "regex", "regex": "YouTube|Plex|VLC"}),
    (
        ["Media", "Social Media"],
        {
            "type": "regex",
            "regex": "reddit|Facebook|Twitter|Instagram|devRant",
            "ignore_case": True,
        },
    ),
    (
        ["Media", "Music"],
        {"type": "regex", "regex": "Spotify|Deezer", "ignore_case": True},
    ),
    (
        ["Comms", "IM"],
        {
            "type": "regex",
            "regex": "Messenger|Telegram|Signal|WhatsApp|Rambox|Slack|Riot|Discord|Nheko",
        },
    ),
    (
        ["Comms", "Email"],
        {"type": "regex", "regex": "Gmail|Thunderbird|mutt|alpine"},
    ),
]


def get_classes() -> List[Tuple[List[str], dict]]:
    """
    Get classes from server-side settings.
    Might throw a 404 if not set yet, in which case we use the default classes as a fallback.
    """
    # NOTE: Always tries to fetch from prod server,
    #       which is potentially wrong if testing server is being used.
    awc = jcp_plus_pulp_client.PULPMonitorClient(f"get-setting-{random.randint(0, 10000)}")
    try:
        classes = awc.get_setting("classes")
    except Exception:
        logger.warning(
            "Failed to get classes from server, using default classes as fallback"
        )
        return default_classes
    # map into list of tuples
    return [(v["name"], v["rule"]) for v in classes]
