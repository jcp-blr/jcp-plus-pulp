from jcp_plus_pulp_client import cli

cli.main()
