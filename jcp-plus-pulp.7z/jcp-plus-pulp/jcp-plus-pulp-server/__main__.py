import jcp_plus_pulp_server

jcp_plus_pulp_server.main()
