from jcp_plus_pulp_monitor_input.main import main

if __name__ == "__main__":
    main()
