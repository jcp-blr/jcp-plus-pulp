from jcp_plus_pulp_sync import main

if __name__ == '__main__':
    main()
