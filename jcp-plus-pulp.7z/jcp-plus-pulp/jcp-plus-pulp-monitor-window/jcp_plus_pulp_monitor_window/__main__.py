from jcp_plus_pulp_monitor_window import main

if __name__ == "__main__":
    main()
