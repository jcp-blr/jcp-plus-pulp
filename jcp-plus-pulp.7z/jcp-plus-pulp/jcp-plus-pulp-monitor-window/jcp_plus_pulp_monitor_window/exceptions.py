class FatalError(Exception):
    """Exception raised when the program should exit with a fatal error."""
